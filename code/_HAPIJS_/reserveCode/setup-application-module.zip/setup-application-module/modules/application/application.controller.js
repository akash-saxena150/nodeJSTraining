module.exports = {

    find(req, reply){
        reply('TODO, GET Application is not implemented yet!');
    }
};